from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # Admin paneli
    path('', include('make_a_cookie.urls')),  # make_a_cookie uygulamasının URL'lerini dahil et
]
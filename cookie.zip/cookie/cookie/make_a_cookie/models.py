from django.db import models

class Recipe(models.Model):
    name = models.CharField(max_length=200, default="Tarif Adı Yok")  # Varsayılan değer eklendi
    description = models.TextField(default="Açıklama yok")  # Varsayılan değer eklendi
    steps = models.JSONField(default=list)  # Adımlar JSON formatında tutulacak

    def __str__(self):
        return self.name
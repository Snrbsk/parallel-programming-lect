from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.conf import settings
import json
import os


def index(request):
    return render(request, 'index.html')

def apple_cookie(request):
    return render(request, 'apple_cookie.html')

RECIPE_FILE_PATH = os.path.join('static/data/recipe_new.json')

def add_recipe(request):
    if request.method == "POST":
        data = json.loads(request.body)
        recipes = []

        # Eğer dosya mevcutsa oku
        if os.path.exists(RECIPE_FILE_PATH):
            with open(RECIPE_FILE_PATH, 'r') as file:
                recipes = json.load(file)

        # Yeni tarifi ekle
        recipes.append(data)

        # JSON dosyasını güncelle
        with open(RECIPE_FILE_PATH, 'w') as file:
            json.dump(recipes, file, indent=4)

        return JsonResponse({'message': 'Tarif eklendi!'}, status=201)

def recipe_list(request):
    # JSON dosyasının tam yolu
    json_file_path = os.path.join(settings.BASE_DIR, 'static', 'data', 'recipe_new.json')

    # JSON dosyasını aç ve yükle
    with open(json_file_path) as json_file:
        recipes = json.load(json_file)  # JSON dosyasını yükle

    # Tarifleri şablona gönder
    return render(request, 'recipe_list.html', {'recipes': recipes})


def recipe_detail(request, recipe_id):
    # JSON dosyasının yolu
    json_file_path = os.path.join(settings.BASE_DIR, 'static', 'data', 'recipe_new.json')

    # JSON dosyasını oku
    with open(json_file_path, 'r', encoding='utf-8') as f:
        recipes = json.load(f)

    index = recipe_id - 1  # recipe_id sıfırdan başladığı için 1 azaltıyoruz

    # Belirtilen tarifin detayını bul
    if 0 <= index < len(recipes):
        recipe = recipes[index]
    else:
        recipe = None  # Tarif bulunamadı

    return render(request, 'recipe_detail.html', {'recipe': recipe, 'recipe_index': index})

def calculate_time(request):
    if request.method in ['POST', 'GET']:
        recipe_id = request.POST.get('recipe_id') or request.GET.get('recipe_id')
        
        # JSON dosyasının yolunu belirleyin
        if recipe_id == 'recipe1':
            json_file_path = os.path.join(settings.BASE_DIR, 'static', 'data', 'recipe1.json')
        elif recipe_id == 'recipe2':
            json_file_path = os.path.join(settings.BASE_DIR, 'static', 'data', 'recipe2.json')
        elif recipe_id == 'recipe_new':
            json_file_path = os.path.join(settings.BASE_DIR, 'static', 'data', 'recipe_new.json')
            index = request.GET.get('index', None)
            index = int(index) +1
        else:
            return JsonResponse({'error': 'Invalid recipe_id'}, status=400)
        # JSON dosyasını oku
        try:
            with open(json_file_path, 'r') as file:
                data = json.load(file)
                if recipe_id == 'recipe_new':
                    data = data[index]
            

            # Burada, JSON içeriğini al ve tasks ismiyle kaydet
            tasks = data.get('steps', [])

            # Initialize start, end, and completed fields for each step
            for task in tasks:  # tasks burada bir liste
                task["start"] = 0
                task["end"] = 0
                task["completed"] = False

            def find_task_by_id(task_id):
                return next((task for task in tasks if task["step"] == task_id), None)
            
            def calculate_minimum_time():
                current_time = 0
                ongoing_tasks = []

                while True:
                    # Find tasks that are ready to start
                    ready_tasks = []  # Yeni durumda completed olanları eklemeyeceğiz
                    for task in tasks:
                        if task["completed"]:
                            continue  # Task zaten tamamlanmış

                        dependencies_met = all(find_task_by_id(dependencies)["completed"] for dependencies in task["dependencies"])
                        if dependencies_met:
                            ready_tasks.append(task)

                    # Eğer hazır görev yoksa ve tüm görevler tamamlandıysa çık
                    if not ready_tasks and all(task["completed"] for task in tasks):
                        break

                    # Şef gerektirmeyen görevleri işleyin
                    for task in ready_tasks:
                        if not task["occupies_chef"] and task not in ongoing_tasks:
                            task["start"] = current_time
                            task["end"] = task["start"] + task["time"]
                            ongoing_tasks.append(task)

                    # Şef gerektiren görevleri işleyin
                    if any(task["occupies_chef"] for task in ready_tasks):
                        for task in ready_tasks:
                            if task["occupies_chef"]:
                                task["start"] = current_time
                                task["end"] = task["start"] + task["time"]
                                ongoing_tasks.append(task)
                                break

                    # Zamanı ileriye taşı ve görevleri tamamla
                    min_end_time = min(task["end"] for task in ongoing_tasks)
                    current_time = min_end_time

                    for task in ongoing_tasks:
                        if task["end"] == current_time:
                            task["completed"] = True

                        if not task["occupies_chef"]:
                            temp_time = task["end"]
                            if any(t["occupies_chef"] for t in ongoing_tasks):
                                for t in ongoing_tasks:
                                    if t["occupies_chef"] and t["end"] > temp_time:
                                        current_time = t["start"]

                    # Tamamlanan görevleri kaldır
                    ongoing_tasks = [task for task in ongoing_tasks if not task["completed"]]

                # Sonuçları göster
                print(f"Your recipe took {current_time} minutes to cook.")
                return current_time
            
            # Hesaplamayı çalıştır
            total_time = calculate_minimum_time()

            # Tarife göre uygun yönlendirme
            if recipe_id in ["recipe1", "recipe2"]:   
                return render(request, 'index.html', {'total_time': total_time})
            else:
                index = request.GET.get('index', None)  # İndeks değerini GET'ten al
                return render(request, 'recipe_detail.html', {'total_time': total_time, 'recipe_index': index})

        except FileNotFoundError:
            return JsonResponse({"error": f"JSON file for {recipe_id} not found."}, status=404)
        except json.JSONDecodeError:
            return JsonResponse({"error": "Error decoding JSON."}, status=400)
    return JsonResponse({"error": "Invalid request."}, status=400)


from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Ana sayfa - Tariflerin listelendiği sayfa    
    path('add-recipe/', views.add_recipe, name='add-recipe'),  # URL tanımı
    path('recipes/<int:recipe_id>/', views.recipe_detail, name='recipe-detail'),
    path('recipes/', views.recipe_list, name='recipe-list'),  # Tarif listesi için
    path('calculate-time/', views.calculate_time, name='calculate_time'),

]
